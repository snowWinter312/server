import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: [ './dashboard.component.css' ]
})
export class DashboardComponent implements OnInit {
  administrator = 0;
  rememberMe : any
  current_user : any
  
  constructor(private router: Router) { }

  ngOnInit() {
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('ID')){
	  this.router.navigate(["/login"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_user = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_user.ID){
		this.router.navigate(["/login"]).then(() => { window.location.reload();})  
	  }
    }
	
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
	this.administrator = +sessionStorage.getItem('group_level');
  }
  
}
