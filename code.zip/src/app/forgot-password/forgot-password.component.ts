import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import {EncrDecrService} from '../encr-decr.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})

export class ForgotPasswordComponent implements OnInit {

  is_show_alert = false
  is_confirm_alert = false
  is_default = true;
  rememberMe : any
  data : any
  
  constructor(private _router: Router, private http: HttpClient, private EncrDecr: EncrDecrService) { }

  ngOnInit() {
    this.is_show_alert = false
	this.is_confirm_alert = false
	this.is_default = true
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (sessionStorage.getItem('ID')){
	  //this._router.navigateByUrl("/dashboard/0/0")	
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.data = JSON.parse(localStorage.getItem('currentUser'))
	  sessionStorage.setItem('ID', this.data.ID)
	  sessionStorage.setItem('username', this.data.username)
	  sessionStorage.setItem('email', this.data.email)
	  sessionStorage.setItem('role', this.data.role)
	  sessionStorage.setItem('group_level', this.data.group_level)
	  //this._router.navigateByUrl("/dashboard/0/0")
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
    }
  }

  onClickSubmit(data){
    var email = data.email
    var pattern =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (pattern.test(email) ){
      this.is_show_alert = false
      data.user_activation_key = this.EncrDecr.set(data.email)

      const headers = new HttpHeaders().set('Content-Type', 'application/json');
		
      this.http.post(environment.serverUrl+'/api/v1/password', JSON.stringify(data), {
        headers: headers
      }).subscribe((data1 : any) => {
        
        if (data1.length){          
            /*
            this.http.post(environment.serverUrl+'/api/v1/forgot_email', JSON.stringify(data), {
              headers: headers
            }).subscribe((data : any) => {
              this.is_confirm_alert = true
		          this.is_default = false;
            });
            */
            this.is_confirm_alert = true
		        this.is_default = false;
        }else{
          this.is_show_alert = true
        }
      })
    }else{
      this.is_show_alert = true
    }

  }

}
