import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-rooms',
  templateUrl: './admin-rooms.component.html',
  styleUrls: ['./admin-rooms.component.css']
})

export class AdminRoomsComponent implements OnInit {
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute, private fb: FormBuilder) {
	this.form = this.fb.group({
		checkArray: this.fb.array([])
	  })  
	this.form_search = new FormGroup({
       ID : new FormControl(''),
       room_name : new FormControl(''),
       parent_id : new FormControl(''),
       doctor_id : new FormControl(''),
       therapist_id : new FormControl(''),
       room_status : new FormControl('')
    }); 
  }
  
  form : FormGroup;
  form_search : FormGroup;
  checkArray: FormArray;
  last_id = 0;
  
  rememberMe : any
  current_user : any
  errors : any
  error_flag = 0;  
  group_level=0;
  rooms = [];
  data = {'checkbox':0,'ID':'', 'room_ID':"", 'room_name':'', 'parent_id':'','doctor_id':'','therapist_id':'','room_status':''};
  check_list ={'checked_rooms':''}
  room_flag=0;
    
  ngOnInit(): void {
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_user = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_user.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }	
    this.getRooms(); 
	this.checkArray = this.form.get('checkArray') as FormArray;	
  }
  
  getRooms(): void {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/rooms', this.current_user, {
	  headers: headers
	}).subscribe((data : any) => { 
	  if (data.length != 0 ){
		this.rooms = data;
		for (let i=0; i<data.length; i++){
			this.rooms[i].checkbox = 0;
			this.last_id = this.rooms[i].ID;
		}
		this.room_flag = 1;
	  }
	})	
  }
  
  onSearch(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
		
    this.http.post(environment.serverUrl+'/api/v1/room_search', JSON.stringify(this.form_search.value), {
        headers: headers
    }).subscribe((data : any) => {
        //console.log(data)
        if (data.length != 0 ){
          this.rooms = data;
		  this.room_flag = 1;
        } else {
		  this.room_flag = 0;
		}
    },error => {
		this.error_flag = 1
		this.errors = error;
	})  
  } 
  
  onDelete(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.check_list.checked_rooms = this.checkArray.value.toString()
	if (this.check_list.checked_rooms != '') {
		this.http.post(environment.serverUrl+'/api/v1/room_delete', JSON.stringify(this.check_list), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.rooms = data;
			  this.room_flag = 1;
			} else {
			  this.room_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		}) 
	}	
  } 
  
  onDeleteOne(id){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.data.ID = id
		this.http.post(environment.serverUrl+'/api/v1/room_delete_one', JSON.stringify(this.data), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.rooms = data;
			  this.room_flag = 1;
			} else {
			  this.room_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		})
  } 
  
  onCheckboxChange(e) {
	  if (e.target.checked) {
		this.checkArray.push(new FormControl(e.target.value));
	  } else {
		let i: number = 0;
		this.checkArray.controls.forEach((item: FormControl) => {
		  if (item.value == e.target.value) {
			this.checkArray.removeAt(i);
			return;
		  }
		  i++;
		});
	  }
  }
  
  onCheck() {
	  for (let i=0; i<this.rooms.length ; i++){
		this.rooms[i].checkbox = 1;
		this.checkArray.push(new FormControl(this.rooms[i].ID));
	  }
	  
  }
  
  onUncheck() {
	  for (let i=this.rooms.length-1; i>=0 ; i--){
		this.rooms[i].checkbox = 0;
		this.checkArray.removeAt(i);
	  }
  }

}
