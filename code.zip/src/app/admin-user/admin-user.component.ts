import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import {EncrDecrService} from '../encr-decr.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-user',
  templateUrl: './admin-user.component.html',
  styleUrls: ['./admin-user.component.css']
})

export class AdminUserComponent implements OnInit {

  rememberMe : any
  current_user : any
  group_level=0;
  errors : any
  error_flag = 0;  
  user ={'ID':0, 'username':0, 'email':'', 'user_registered':'', 'user_confirmed':'', 'role':'', 'group_level':'', 'confirm_status':'', 'user_status':''}
  user_flag=0;
  role =4;
  confirm_status=1;
  user_status=1;
  user_id=0;
  is_show_alert = 0;
  is_db_alert = 0;
  is_confirm_alert = 0;  
 
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute,private EncrDecr: EncrDecrService) { }

  ngOnInit() {
	  
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_user = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_user.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }
	this.user.ID = +this.route.snapshot.paramMap.get('id');
    if (this.user.ID == 0){
		this.user_flag = 0;
	} else {
		this.getUser();
	}
	
  }

  getUser(): void {
	const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/user', JSON.stringify(this.user), {
        headers: headers
    }).subscribe((data : any) => {
        if (data.length != 0 ){
			this.user = data;
			this.user_flag = 1;
		} else {
			this.user_flag = 0;
		}
    },error => {
		this.error_flag = 1
        this.errors = error;
    }) 
  }
  
  onUpdate(data){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	  if (data.ID) {
		if (data.username != "" && data.username != null) {
		  this.http.post(environment.serverUrl+'/api/v1/update', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			//console.log(data)
			if (data.affectedRows == 1 || data.insertId == 1){        
			  //this.user = data;
			  this.user_flag = 1;
			  this.is_confirm_alert = 1;
			  this.is_show_alert = 0;
			} else {
			  this.is_db_alert = 1;
			  this.is_show_alert = 0;
			}
		  },error => {
			this.error_flag = 1
			this.errors = error;
		  })  
		} else {
			this.is_show_alert = 1;
		}
	  } else {
		if (data.username != "" && data.username != null) {
		  data.password = this.EncrDecr.set(data.password)
		  this.http.post(environment.serverUrl+'/api/v1/create', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			//console.log(data)
			if (data.insertId != undefined){        
			  //this.user = data;
			  this.is_confirm_alert = 1;
			  this.is_show_alert = 0;
			} else {
			  this.is_db_alert = 1;
			  this.is_show_alert = 0;
			}
		  },error => {
			this.error_flag = 1
			this.errors = error;
		  })  
		} else {
		  this.is_show_alert = 1;
		  this.is_db_alert = 0;
		  this.is_db_alert = 0;
		}  
	  }
  }

}
