import { NgModule} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { LeftComponent } from './left/left.component';
import { RightComponent } from './right/right.component';
import { LogoutComponent } from './logout/logout.component';
import { PasswordSettingComponent } from './password-setting/password-setting.component';

import { EditorModule } from '@tinymce/tinymce-angular';
import {EncrDecrService} from './encr-decr.service';
import { AdminComponent } from './admin/admin.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminRoomsComponent } from './admin-rooms/admin-rooms.component';
import { AdminPostsComponent } from './admin-posts/admin-posts.component';
import { AdminCommentsComponent } from './admin-comments/admin-comments.component';
import { AdminUserComponent } from './admin-user/admin-user.component';
import { AdminRoomComponent } from './admin-room/admin-room.component';
import { AdminPostComponent } from './admin-post/admin-post.component';
import { AdminCommentComponent } from './admin-comment/admin-comment.component';
import { RedirectComponent } from './redirect/redirect.component';
import { SateHtmlPipe } from './sate-html.pipe';
import { AdminPostNewComponent } from './admin-post-new/admin-post-new.component';
import { BnNgIdleService } from 'bn-ng-idle';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    RegisterComponent,
    ForgotPasswordComponent,
    LeftComponent,
    RightComponent,
    LogoutComponent,
    PasswordSettingComponent,
    AdminComponent,
    ConfirmComponent,
    AdminUsersComponent,
    AdminRoomsComponent,
    AdminPostsComponent,
    AdminCommentsComponent,
    AdminUserComponent,
    AdminRoomComponent,
    AdminPostComponent,
    AdminCommentComponent,
    RedirectComponent,
    SateHtmlPipe,
    AdminPostNewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
	  EditorModule,
    ReactiveFormsModule,
    // The HttpClientInMemoryWebApiModule module intercepts HTTP requests
    // and returns simulated server responses.
    // Remove it when a real server is ready to receive requests.
    
  ],
  providers: [EncrDecrService, BnNgIdleService],
  exports: [],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
