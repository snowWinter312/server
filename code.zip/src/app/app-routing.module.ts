import { NgModule } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { PasswordSettingComponent } from './password-setting/password-setting.component';
import { RightComponent } from './right/right.component';
import { AdminComponent } from './admin/admin.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminUserComponent } from './admin-user/admin-user.component';
import { AdminRoomsComponent } from './admin-rooms/admin-rooms.component';
import { AdminRoomComponent } from './admin-room/admin-room.component';
import { AdminPostsComponent } from './admin-posts/admin-posts.component';
import { AdminPostComponent } from './admin-post/admin-post.component';
import { AdminPostNewComponent } from './admin-post-new/admin-post-new.component';
import { AdminCommentsComponent } from './admin-comments/admin-comments.component';
import { AdminCommentComponent } from './admin-comment/admin-comment.component';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/0/0', pathMatch: 'full' },
  { path: 'dashboard/:id1/:id2', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'confirm/:id', component: ConfirmComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'password-setting/:id', component: PasswordSettingComponent },  
  { path: 'right/:id1/:id2', component: RightComponent },
  { path: 'admin/:id', component: AdminComponent },
  { path: 'admin-users', component: AdminUsersComponent },
  { path: 'admin-user/:id', component: AdminUserComponent },
  { path: 'admin-rooms', component: AdminRoomsComponent },
  { path: 'admin-room/:id', component: AdminRoomComponent },
  { path: 'admin-posts', component: AdminPostsComponent },
  { path: 'admin-post/:id', component: AdminPostComponent },
  { path: 'admin-post-new', component: AdminPostNewComponent },
  { path: 'admin-comments', component: AdminCommentsComponent },
  { path: 'admin-comment/:id', component: AdminCommentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
