import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-comment',
  templateUrl: './admin-comment.component.html',
  styleUrls: ['./admin-comment.component.css']
})
export class AdminCommentComponent implements OnInit {
	
  rememberMe : any
  current_comment : any
  group_level=0;
  errors : any
  error_flag = 0;  
  
  comment = {'ID':0, 'comment_post_ID':"", 'comment_author_ID':'', 'comment_date':'','comment_content':'','comment_approved':'','comment_type':'','comment_parent':''};
  
  comment_flag=0;
  is_show_alert = 0;
  is_db_alert = 0;
  is_confirm_alert = 0;
  comment_approved = 1;
  comment_type=0;
  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute) { }

  ngOnInit() {
	  
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_comment = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_comment.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }
	this.comment.ID = +this.route.snapshot.paramMap.get('id');
	if (this.comment.ID == 0){
		this.comment_flag = 0;
	} else {
		this.getRoom();
	}
    
	
  }

  getRoom(): void {
	const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/comment', JSON.stringify(this.comment), {
        headers: headers
    }).subscribe((data : any) => {
        if (data.length != 0 ){
			this.comment = data;
			this.comment_flag = 1;
		} else {
			this.comment_flag = 0;
		}
    },error => {
		this.error_flag = 1
        this.errors = error;
    }) 
  }
  
  onUpdate(data){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	if (data.ID) {
      if (data.comment_content != "" && data.comment_content != null) {
		  this.http.post(environment.serverUrl+'/api/v1/comment_update', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			//console.log(data)
			if (data.affectedRows == 1 || data.insertId == 1){        
			  //this.comment = data;
			  this.comment_flag = 1;
			  this.is_confirm_alert = 1;
			  this.is_show_alert = 0;
			} else {
			  this.is_db_alert = 1;
			  this.is_show_alert = 0;
			}
		  },error => {
			this.error_flag = 1
			this.errors = error;
		  }) 
	  } else {
		this.is_show_alert = 1;
		this.is_db_alert = 0;
		this.is_db_alert = 0;
	  }
	} else {
	  if (data.comment_content != "" && data.comment_content != null) {
		this.http.post(environment.serverUrl+'/api/v1/comment_create', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			//console.log(data)
			if (data.insertId != undefined){        
			  //this.comment = data;
			  this.is_confirm_alert = 1;
			  this.is_show_alert = 0;
			} else {
			  this.is_db_alert = 1;
			  this.is_show_alert = 0;
			}
		  },error => {
			this.error_flag = 1
			this.errors = error;
		  })
	  } else {
		this.is_show_alert = 1;
		this.is_db_alert = 0;
		this.is_db_alert = 0;
	  }
	}
  }


}
