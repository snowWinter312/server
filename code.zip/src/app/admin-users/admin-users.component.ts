import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.css']
})
export class AdminUsersComponent implements OnInit {

  form : FormGroup;
  form_search : FormGroup;
  checkArray: FormArray;
  last_id = 0;  
  data = {'checkbox':0,'ID':'', 'room_id':"", 'sub_room_id':'', 'tab_id':'','user_author':'','user_date':'','user_content':'','user_status':'','comment_status':'','user_modified':'','comment_count':''};
  check_list ={'checked_users':''}
  
  rememberMe : any
  current_user : any
  users = []
  user_flag=0;
  errors : any
  error_flag = 0;  
  group_level=0;
  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute, private fb: FormBuilder) { 
	this.form = this.fb.group({
		checkArray: this.fb.array([])
	  })  
	this.form_search = new FormGroup({
       ID : new FormControl(''),
       username : new FormControl(''),
       role : new FormControl(''),
       confirm_status : new FormControl(''),
       user_status : new FormControl('')
    }); 
  }
  ngOnInit() {
	  
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_user = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_user.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }	
    this.getUsers();
	this.checkArray = this.form.get('checkArray') as FormArray;			
  }

  getUsers(): void {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/users', this.current_user, {
	  headers: headers
	}).subscribe((data : any) => { 
	  if (data.length != 0 ){
		this.users = data;
		this.user_flag = 1;
	  }
	})	
  }
  
  onSearch(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');

    this.http.post(environment.serverUrl+'/api/v1/search', JSON.stringify(this.form_search.value), {
        headers: headers
    }).subscribe((data : any) => {
        //console.log(data)
        if (data.length != 0 ){
          this.users = data;
		  this.user_flag = 1;
        } else {
		  this.user_flag = 0;
		}
    },error => {
		this.error_flag = 1
		this.errors = error;
	})  
  }

  onDelete(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.check_list.checked_users = this.checkArray.value.toString()
	if (this.check_list.checked_users != '') {
		this.http.post(environment.serverUrl+'/api/v1/delete_all', JSON.stringify(this.check_list), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.users = data;
			  this.user_flag = 1;
			} else {
			  this.user_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		}) 
	}	
  } 
  
  onDeleteOne(id){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.data.ID = id
		this.http.post(environment.serverUrl+'/api/v1/delete_one', JSON.stringify(this.data), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.users = data;
			  this.user_flag = 1;
			} else {
			  this.user_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		})
  } 
  
  onCheckboxChange(e) {
	  if (e.target.checked) {
		this.checkArray.push(new FormControl(e.target.value));
	  } else {
		let i: number = 0;
		this.checkArray.controls.forEach((item: FormControl) => {
		  if (item.value == e.target.value) {
			this.checkArray.removeAt(i);
			return;
		  }
		  i++;
		});
	  }
  }
  
  onCheck() {
	  for (let i=0; i<this.users.length ; i++){
		this.users[i].checkbox = 1;
		this.checkArray.push(new FormControl(this.users[i].ID));
	  }
	  
  }
  
  onUncheck() {
	  for (let i=this.users.length-1; i>=0 ; i--){
		this.users[i].checkbox = 0;
		this.checkArray.removeAt(i);
	  }
  }  
  
}
