import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {EncrDecrService} from '../encr-decr.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-password-setting',
  templateUrl: './password-setting.component.html',
  styleUrls: ['./password-setting.component.css']
})
export class PasswordSettingComponent implements OnInit {
	
  is_show_alert1 = false;
  is_show_alert2 = false;
  is_confirm_alert = false;
  user_activation_key = ""
  rememberMe:any
  data : any	  
	  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute ,private EncrDecr: EncrDecrService) { }

  ngOnInit(): void {
	this.user_activation_key = this.route.snapshot.paramMap.get('id');
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
	
    if (sessionStorage.getItem('ID')){
	  //this._router.navigateByUrl("/dashboard/0/0")	
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.data = JSON.parse(localStorage.getItem('currentUser'))
	  sessionStorage.setItem('ID', this.data.ID)
	  sessionStorage.setItem('username', this.data.username)
	  sessionStorage.setItem('email', this.data.email)
	  sessionStorage.setItem('role', this.data.role)
	  sessionStorage.setItem('group_level', this.data.group_level)
	  //this._router.navigateByUrl("/dashboard/0/0")
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
    }

  }

  onClickSubmit(data){
	var pass = data.password
	var confirm_password = data.confirm_password 
	
    if ( pass == confirm_password ){
      if ( pass == null || confirm_password == null ) {
		this.is_show_alert2 = true  
	  } else {
		const headers = new HttpHeaders().set('Content-Type', 'application/json');
		data.password = this.EncrDecr.set(pass)	
		
		  this.http.post(environment.serverUrl+'/api/v1/changing', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			
			if (data.affectedRows == 1){
				this._router.navigate(["/login"]).then(() => { window.location.reload();})
			} else {
				this.is_confirm_alert = true
			}
		  })  
	  }
      
    }else{
      this.is_show_alert1 = true
    }

  }
  
}
