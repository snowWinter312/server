import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { EditorModule } from '@tinymce/tinymce-angular';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-right',
  templateUrl: './right.component.html',
  styleUrls: ['./right.component.css']
})
export class RightComponent implements OnInit {

  conversations =[]
  conversations_ID =[]
  weeks=[]
  days=[]
  temp = []
  comments=[]
  comments_temp=[]
  room_id=0
  sub_id=0
  
  data:any
  conversationFlag=1;
  editor:any
  content : any
  comment_post_ID:any
  comment_parent:any
  
  
  constructor(private http: HttpClient,private route: ActivatedRoute, private _router: Router, private location: Location) { }

  ngOnInit(): void {
    this.getRight();
	//this.content ="12121212"
  }

  getRight(){
    this.room_id = +this.route.snapshot.paramMap.get('id1');
    this.sub_id = +this.route.snapshot.paramMap.get('id2');
	var user_id = +sessionStorage.getItem('ID');
	var role = +sessionStorage.getItem('role');
	
	this.data={'room_id':this.room_id, 'sub_id':this.sub_id, 'user_id':user_id, 'role':role};
    
    if (this.room_id != 0 && this.sub_id != 0 ){
      
      const headers = new HttpHeaders().set('Content-Type', 'application/json');
	  
	  this.http.post(environment.serverUrl+'/api/v1/conversations', JSON.stringify(this.data), {
        headers: headers
      }).subscribe((data : any) => {    
        
        if (data.length != 0 && data.length != undefined){
          this.conversations = data;
		  this.http.post(environment.serverUrl+'/api/v1/days', JSON.stringify(this.data), {
			headers: headers
		  }).subscribe((data : any) => {    
			
			if (data.length != 0 ){
			  this.days = data;
			  for (let i=0;i<this.days.length;i++){
				   var p=0; this.temp =[];
				 for (var j=0; j< this.conversations.length; j++){
					 if (this.days[i].week ==this.conversations[j].week && this.days[i].day_of_week == this.conversations[j].day_of_week) {
						this.temp[p] = this.conversations[j];
						p = p+1;
					 }
					 this.conversations_ID[j]=this.conversations[j].ID
				 }
				 this.days[i].temp = this.temp;
			  }
			}
			
			this.http.post(environment.serverUrl+'/api/v1/weeks', JSON.stringify(this.data), {
				headers: headers
			  }).subscribe((data : any) => {    
				
				if (data.length != 0  && data.length != undefined){
				  this.weeks = data;
				  for (let i=0;i<this.weeks.length;i++){
					var p=0; this.temp =[];
				    for (let j=0; j< this.days.length; j++){
					  if (this.weeks[i].week ==this.days[j].week) {
						this.temp[p] = this.days[j];
						p = p+1;
					  }
				    }
					if (this.conversations[0].first_week == 0 ){
					  this.weeks[i].week = +this.weeks[i].week + 1;						  				  
					} 
					this.weeks[i].temp = this.temp;	
				  }
				}
				
				this.data.post_id = this.conversations_ID.toString()
				  this.http.post(environment.serverUrl+'/api/v1/comments', JSON.stringify(this.data), {
					headers: headers
				  }).subscribe((data : any) => { 
					if (data.length != 0  && data.length != undefined){
						
						for (let i=0;i<this.conversations.length;i++){
							var comment_dup = 0;
							this.comments_temp =[];
							for (let j=0; j< data.length; j++){
								if (this.conversations[i].ID == data[j].comment_post_ID && data[j].comment_parent == 0 ){
									this.comments_temp[comment_dup] = data[j];
									comment_dup = comment_dup + 1;
								} 
							}
							this.conversations[i].temp = this.comments_temp
							this.conversations[i].number_of_comment = comment_dup		
							
							for (let k=0; k< this.conversations[i].temp.length; k++){
								var comment_dup = 0; this.comments_temp =[];
								for (let j=0; j< data.length; j++){
									if (this.conversations[i].ID == data[j].comment_post_ID && data[j].comment_parent != 0 && this.conversations[i].temp[k].ID == data[j].comment_parent){
										this.comments_temp[comment_dup] = data[j];
										comment_dup = comment_dup + 1;
									} 
								}
								this.conversations[i].temp[k].temp = this.comments_temp
								this.conversations[i].temp[k].number_of_reply = comment_dup	
							}
						
						}
					}
				  })
			  })
			
		  })
        } else {
			this.conversationFlag = 0;
		}
      })	  
    } else {
      this.conversationFlag = 0;
    }
  }
  
  onClickEditor(editor){
    
  }
  
  commentFormShow(conversation_id):void{
	document.getElementById("comment"+conversation_id).hidden=false; 
	this.comment_post_ID = conversation_id;
  }
  
  commentFormHide(conversation_id):void{
	document.getElementById("comment"+conversation_id).hidden=true; 
  }
  
  onCommentSubmit(data){
	var comment = data.comment
	data.comment_post_ID = this.comment_post_ID
	data.room_id = this.room_id;
	data.sub_id = this.sub_id
	data.user_id = sessionStorage.getItem('ID');
	
    if ( comment!= null){
      const headers = new HttpHeaders().set('Content-Type', 'application/json');

      this.http.post(environment.serverUrl+'/api/v1/comment_add', JSON.stringify(data), {
        headers: headers
      }).subscribe((data : any) => {
        //console.log(data)
        
        if (data.insertId != 0 ){		  
          this._router.onSameUrlNavigation = 'reload'      
		  this._router.navigateByUrl("/dashboard/"+this.room_id+"/"+this.sub_id)		      
        }else{
		  document.getElementById("comment_db_alert"+this.comment_post_ID).hidden=false;
        }
      })
    }else{
      document.getElementById("comment_alert"+this.comment_post_ID).hidden=false;
    }
  }
	
  replyFormShow(conversation_id, comment_id):void{
	document.getElementById("reply"+comment_id).hidden=false; 
	this.comment_post_ID = conversation_id;
	this.comment_parent = comment_id
  }
  
  replyFormHide(conversation_id, comment_id):void{
	document.getElementById("reply"+comment_id).hidden=true; 
  }
  
  onReplySubmit(data){
	var comment = data.reply
	data.comment_post_ID = this.comment_post_ID
	data.comment_parent = this.comment_parent
	data.room_id = this.room_id;
	data.sub_id = this.sub_id
	data.user_id = sessionStorage.getItem('ID');
	
    if ( comment!= null){
      const headers = new HttpHeaders().set('Content-Type', 'application/json');

      this.http.post(environment.serverUrl+'/api/v1/reply_add', JSON.stringify(data), {
        headers: headers
      }).subscribe((data : any) => {
        //console.log(data)
        
        if (data.insertId != 0 ){	
		  this._router.onSameUrlNavigation = 'reload'          	  
          this._router.navigateByUrl("/dashboard/"+this.room_id+"/"+this.sub_id)
        }else{
		  document.getElementById("reply_db_alert"+this.comment_parent).hidden=false;
        }
      })
    }else{
      document.getElementById("reply_alert"+this.comment_parent).hidden=false;
    }
  }
  
  commentDelete(comment_type, comment_id):void{
	  const headers = new HttpHeaders().set('Content-Type', 'application/json');
	  this.data.ID = comment_id
      this.http.post(environment.serverUrl+'/api/v1/comment_delete_front', JSON.stringify(this.data), {
        headers: headers
      }).subscribe((data : any) => {
        //console.log(data)
        
        if (data.affectedRows != 0 ){	
		  if (comment_type == 1) {
			document.getElementById("comment"+comment_id).remove();
		  } else {
			document.getElementById("reply"+comment_id).remove();  
		  }
		  //this._router.onSameUrlNavigation = 'reload'          	  
          //this._router.navigateByUrl("/dashboard/"+this.room_id+"/"+this.sub_id)
        }else{
		  //document.getElementById("reply_db_alert"+this.comment_parent).hidden=false;
        }
      })
  }

}
