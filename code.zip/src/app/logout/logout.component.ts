import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
	
  login_status : any;	
	
  constructor(private _router: Router) { }

  ngOnInit(): void {
	  localStorage.setItem('currentUser', '');
      localStorage.setItem('rememberCurrentUser', 'false'); 
	  sessionStorage.setItem('ID', '')
      sessionStorage.setItem('username', '')
      sessionStorage.setItem('email', '')
      sessionStorage.setItem('role', '')
      sessionStorage.setItem('group_level', '')	
	  //
	  //
	  //this._router.navigateByUrl('/', {skipLocationChange: false}).then(()=>this._router.navigate(["/login"]));	  
	  //this._router.navigateByUrl("/login")
	  //this._router.onSameUrlNavigation = 'reload'  
	  this._router.navigate(["/login"]).then(() => { window.location.reload();})
  }

}
