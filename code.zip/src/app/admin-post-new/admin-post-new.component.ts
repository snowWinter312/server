import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-post-new',
  templateUrl: './admin-post-new.component.html',
  styleUrls: ['./admin-post-new.component.css']
})
export class AdminPostNewComponent implements OnInit {

  rememberMe : any
  current_post : any
  group_level=0;
  errors : any
  error_flag = 0;  
  is_show_alert = 0;
  is_db_alert = 0;
  is_confirm_alert = 0;
  post_content = "";
  post_status = 1;
  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute) { }

  ngOnInit() {
	  
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_post = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_post.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }
	this.post_status = 1;
  }

  
  
  onCreate(data){
      const headers = new HttpHeaders().set('Content-Type', 'application/json');
      if (data.post_content != "" && data.post_content != null) {
	    data.post_author = sessionStorage.getItem('ID')
		this.http.post(environment.serverUrl+'/api/v1/post_create', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			//console.log(data)
			if (data.insertId != undefined){        
			  //this.room = data;
			  this.is_confirm_alert = 1;
			} else {
			  this.is_db_alert = 1;
			}
		  },error => {
			this.error_flag = 1
			this.errors = error;
		  })
	  } else {
		this.is_show_alert = 1;
	  }
  }

}
