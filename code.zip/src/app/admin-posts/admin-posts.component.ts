import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-posts',
  templateUrl: './admin-posts.component.html',
  styleUrls: ['./admin-posts.component.css']
})

export class AdminPostsComponent implements OnInit {

  form : FormGroup;
  form_search : FormGroup;
  checkArray: FormArray;
  last_id = 0;  
  data = {'checkbox':0,'ID':'', 'room_id':"", 'sub_room_id':'', 'tab_id':'','post_author':'','post_date':'','post_content':'','post_status':'','comment_status':'','post_modified':'','comment_count':''};
  check_list ={'checked_posts':''}
  
  rememberMe : any
  current_user : any
  errors : any
  error_flag = 0;  
  group_level=0;
  posts = []
  post_flag=0;
  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute, private fb: FormBuilder) { 
	this.form = this.fb.group({
		checkArray: this.fb.array([])
	  })  
	this.form_search = new FormGroup({
       ID : new FormControl(''),
       room_id : new FormControl(''),
       sub_room_id : new FormControl(''),
       post_author : new FormControl(''),
       post_content : new FormControl(''),
       post_status : new FormControl('')
    }); 
  }

  ngOnInit(): void {
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_user = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_user.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }	
    this.getPosts(); 
	this.checkArray = this.form.get('checkArray') as FormArray;			  
  }
  
  getPosts(): void {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/post_all', this.current_user, {
	  headers: headers
	}).subscribe((data : any) => { 
	  if (data.length != 0 ){
		this.posts = data;
		for (let i=0; i<data.length; i++){
			this.posts[i].checkbox = 0;
			this.last_id = this.posts[i].ID;
		}
		this.post_flag = 1;
	  }
	})	
  }
  
  onSearch(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');

    this.http.post(environment.serverUrl+'/api/v1/post_search', JSON.stringify(this.form_search.value), {
        headers: headers
    }).subscribe((data : any) => {
        //console.log(data)
        if (data.length != 0 ){
          this.posts = data;
		  this.post_flag = 1;
        } else {
		  this.post_flag = 0;
		}
    },error => {
		this.error_flag = 1
		this.errors = error;
	})  
  } 

  onDelete(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.check_list.checked_posts = this.checkArray.value.toString()
	if (this.check_list.checked_posts != '') {
		this.http.post(environment.serverUrl+'/api/v1/post_delete', JSON.stringify(this.check_list), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.posts = data;
			  this.post_flag = 1;
			} else {
			  this.post_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		}) 
	}	
  } 
  
  onDeleteOne(id){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.data.ID = id
		this.http.post(environment.serverUrl+'/api/v1/post_delete_one', JSON.stringify(this.data), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.posts = data;
			  this.post_flag = 1;
			} else {
			  this.post_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		})
  } 
  
  onCheckboxChange(e) {
	  if (e.target.checked) {
		this.checkArray.push(new FormControl(e.target.value));
	  } else {
		let i: number = 0;
		this.checkArray.controls.forEach((item: FormControl) => {
		  if (item.value == e.target.value) {
			this.checkArray.removeAt(i);
			return;
		  }
		  i++;
		});
	  }
  }
  
  onCheck() {
	  for (let i=0; i<this.posts.length ; i++){
		this.posts[i].checkbox = 1;
		this.checkArray.push(new FormControl(this.posts[i].ID));
	  }
	  
  }
  
  onUncheck() {
	  for (let i=this.posts.length-1; i>=0 ; i--){
		this.posts[i].checkbox = 0;
		this.checkArray.removeAt(i);
	  }
  }    

}
