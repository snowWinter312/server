import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {EncrDecrService} from '../encr-decr.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  is_show_alert = false;
  is_username_alert = false;
  is_email_alert = false;
  is_confirm_alert = false;
  is_default = true;
  rememberMe : any;
  data : any;
  
  constructor(private _router: Router, private http: HttpClient ,private EncrDecr: EncrDecrService) { }

  ngOnInit() {
    this.is_show_alert = false
	  this.is_confirm_alert = false
	  this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (sessionStorage.getItem('ID')){
	    //this._router.navigateByUrl("/dashboard/0/0")	
	    this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
    } else if (this.rememberMe == true) {
      this.data = JSON.parse(localStorage.getItem('currentUser'))
      sessionStorage.setItem('ID', this.data.ID)
      sessionStorage.setItem('username', this.data.username)
      sessionStorage.setItem('email', this.data.email)
      sessionStorage.setItem('role', this.data.role)
      sessionStorage.setItem('group_level', this.data.group_level)
      this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
      //this._router.navigateByUrl("/dashboard/0/0")
    }
  }

  onClickSubmit(data){
    var email = data.email
    var pass = data.password	
    data.password = this.EncrDecr.set(pass)
    data.user_activation_key = this.EncrDecr.set(data.email)
    //var ecrypted_password = CryptoJS.MD5("Test");
    var username = data.username
    var pattern =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (pattern.test(email) && pass!= null && username != null ){
      this.is_show_alert = false

      const headers = new HttpHeaders().set('Content-Type', 'application/json');
			  
      this.http.post(environment.serverUrl+'/api/v1/register', JSON.stringify(data), {
        headers: headers
      }).subscribe((data1 : any) => {
        
        
        if (data1.insertId != undefined){
        /*  
          this.http.post(environment.serverUrl+'/api/v1/register_email', JSON.stringify(data), {
				    headers: headers
			    }).subscribe((data1 : any) => {
            this.is_confirm_alert = true
			      this.is_default = false;
			    });
			  */
          this.is_confirm_alert = true
          this.is_default = false;  
        }else{
          if (data1.length){
            if (data1[0].username != undefined){
            this.is_username_alert = true 
          } else if (data1[0].email != undefined) {
            this.is_email_alert = true  
            } 			
          } else {
            this.is_show_alert = true
          }	          
            //this._router.navigateByUrl("/login")
        }
      })
    }else{
      this.is_show_alert = true
  
    }

  }

}
