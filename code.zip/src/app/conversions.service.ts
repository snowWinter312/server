import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class conversationsService {
  conversations = [];
  
  room_select(room_number:any, tab_number:any){
    this.conversations = [100,200,300];    
  }
  constructor() { }
}
