import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import { BnNgIdleService } from 'bn-ng-idle'; // import it to your component
//import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'ngbd-modal-content',
  template: `
    <div class="modal-header">
      <h4 class="modal-title">PIN Code Input</h4>
    </div>
    <div class="modal-body">
      <div class="form-floating">
        <p id="time_modal_alert" class="text-danger" style="display:none">PIN code is wrong, Please input correctly!</p>
        <p>Please type the PIN code that you receiced through the email.</p>
        <input type="text" name="pin" id="pin" value="" >
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-primary" (click)="activeModal.dismiss()">Confirm</button>
    </div>
  `
})
export class NgbdModalContent {
  @Input() name;
  is_show_alert = 0;
  constructor(public activeModal: NgbActiveModal) {}
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers: [Location, {provide: LocationStrategy, useClass: PathLocationStrategy}],
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  location: Location;
  title = 'Forum';
  login_status : any;
  rememberMe : any;
  data : any;
  menu_status = 1
  administrator = 0;
  closeResult : any
  isModalOpen : any;
  pinCode :any
  pinData={'pin': 111111, 'email':""}

  constructor(private _router: Router, private bnIdle: BnNgIdleService, private modalService: NgbModal, private http: HttpClient) { }

  ngOnInit() {
    this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;

    if ((this.rememberMe == true)) {
      this.data = JSON.parse(localStorage.getItem('currentUser'))
      sessionStorage.setItem('ID', this.data.ID)
      sessionStorage.setItem('username', this.data.username)
      sessionStorage.setItem('email', this.data.email)
      sessionStorage.setItem('role', this.data.role)
      sessionStorage.setItem('group_level', this.data.group_level)
    }
    
    if (sessionStorage.getItem("isModalOpen") == "open"){
      this.modalService.open(NgbdModalContent, {'keyboard': false, 'backdrop':'static', beforeDismiss:this.onBefore}) 
    } else {
      sessionStorage.setItem('isModalOpen', 'close')
    }
	
    this.administrator = +sessionStorage.getItem('group_level');  
    this.login_status = +sessionStorage.getItem('ID')    

    this.bnIdle.startWatching(600).subscribe((isTimedOut: boolean) => {
      if (isTimedOut) {
        //console.log('session expired');        

        if (sessionStorage.getItem("isModalOpen") == 'close'){
          
          this.pinCode = Math.floor(Math.random()* 1000000);
          sessionStorage.setItem("pinCode", this.pinCode);
/*
          this.pinData.pin = this.pinCode;
          this.pinData.email = sessionStorage.getItem("email");
          const headers = new HttpHeaders().set('Content-Type', 'application/json');
            this.http.post(environment.serverUrl+'/api/v1/pin_email', JSON.stringify(this.pinData), {
              headers: headers
            }).subscribe((data : any) => {
              
            });
*/
          if (+sessionStorage.getItem("ID") > 0) {            
            sessionStorage.setItem('isModalOpen', 'open')            
            this.modalService.open(NgbdModalContent, {'keyboard': false, 'backdrop':'static', beforeDismiss:this.onBefore}) 
          } 
                 
        }
        
      }
    });    
        
    if (location.href.search("forgot-password")>0 || location.href.search("password-setting")>0 || location.href.search("register")>0 || location.href.search("login")>0|| location.href.search("confirm")>0 ){
      this.menu_status = 0	
    }

  }

  onBefore(){
    this.closeResult = (document.getElementById("pin") as HTMLInputElement).value;
    if ( this.closeResult == sessionStorage.getItem("pinCode")) {
      sessionStorage.setItem('isModalOpen', 'close')
      return true;
    } else {
      (document.getElementById("time_modal_alert") as HTMLInputElement).style.display="block"
      return false;
    }
  }

}
