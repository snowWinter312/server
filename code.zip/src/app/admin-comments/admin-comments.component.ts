import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-comments',
  templateUrl: './admin-comments.component.html',
  styleUrls: ['./admin-comments.component.css']
})
export class AdminCommentsComponent implements OnInit {
  
  form : FormGroup;
  form_search : FormGroup;
  checkArray: FormArray;
  last_id = 0;
  data = {'checkbox':0,'ID':'', 'comment_post_ID':"", 'comment_author_ID':'', 'comment_date':'','comment_content':'','comment_approved':'','comment_type':'','comment_parent':''};
  check_list ={'checked_comments':''}
  
  rememberMe : any
  current_user : any
  errors : any
  error_flag = 0;  
  group_level=0;
  comments = []
  comment_flag=0;  
  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute, private fb: FormBuilder) { 
    this.form = this.fb.group({
		checkArray: this.fb.array([])
	  })  
	this.form_search = new FormGroup({
       ID : new FormControl(''),
       comment_post_ID : new FormControl(''),
       comment_content : new FormControl(''),
       comment_type : new FormControl(''),
       comment_approved : new FormControl('')
    }); 
  }

  ngOnInit(): void {
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_user = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_user.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }	
    this.getComments(); 	
	this.checkArray = this.form.get('checkArray') as FormArray;		
  }
  
  getComments(): void {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/comment_all', this.current_user, {
	  headers: headers
	}).subscribe((data : any) => { 
	  if (data.length != 0 ){
		this.comments = data;
		for (let i=0; i<data.length; i++){
			this.comments[i].checkbox = 0;
			this.last_id = this.comments[i].ID;
		}
		this.comment_flag = 1;
	  }
	})	
  }
  
  onSearch(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');

    this.http.post(environment.serverUrl+'/api/v1/comment_search', JSON.stringify(this.form_search.value), {
        headers: headers
    }).subscribe((data : any) => {
        //console.log(data)
        if (data.length != 0 ){
          this.comments = data;
		  this.comment_flag = 1;
        } else {
		  this.comment_flag = 0;
		}
    },error => {
		this.error_flag = 1
		this.errors = error;
	})  
  } 

  onDelete(){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.check_list.checked_comments = this.checkArray.value.toString()
	if (this.check_list.checked_comments != '') {
		this.http.post(environment.serverUrl+'/api/v1/comment_delete', JSON.stringify(this.check_list), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.comments = data;
			  this.comment_flag = 1;
			} else {
			  this.comment_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		}) 
	}	
  } 
  
  onDeleteOne(id){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	this.data.ID = id
		this.http.post(environment.serverUrl+'/api/v1/comment_delete_one', JSON.stringify(this.data), {
			headers: headers
		}).subscribe((data : any) => {
			//console.log(data)
			if (data.length != 0 ){
			  this.comments = data;
			  this.comment_flag = 1;
			} else {
			  this.comment_flag = 0;
			}
		},error => {
			this.error_flag = 1
			this.errors = error;
		})
  } 
  
  onCheckboxChange(e) {
	  if (e.target.checked) {
		this.checkArray.push(new FormControl(e.target.value));
	  } else {
		let i: number = 0;
		this.checkArray.controls.forEach((item: FormControl) => {
		  if (item.value == e.target.value) {
			this.checkArray.removeAt(i);
			return;
		  }
		  i++;
		});
	  }
  }
  
  onCheck() {
	  for (let i=0; i<this.comments.length ; i++){
		this.comments[i].checkbox = 1;
		this.checkArray.push(new FormControl(this.comments[i].ID));
	  }
	  
  }
  
  onUncheck() {
	  for (let i=this.comments.length-1; i>=0 ; i--){
		this.comments[i].checkbox = 0;
		this.checkArray.removeAt(i);
	  }
  }
  
}
