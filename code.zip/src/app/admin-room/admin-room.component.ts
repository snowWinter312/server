import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-room',
  templateUrl: './admin-room.component.html',
  styleUrls: ['./admin-room.component.css']
})
export class AdminRoomComponent implements OnInit {
  
  rememberMe : any
  current_room : any
  group_level=0;
  errors : any
  error_flag = 0;  
  
  room ={'ID':0, 'room_name':'', 'room_created':'', 'room_status':'', 'parent_id':'', 'doctor_id':'', 'therapist_id':''};
  room_flag=0;
  role = "";
  is_show_alert = 0;
  is_db_alert = 0;
  is_confirm_alert = 0;
  room_status = 0;
  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute) { }

  ngOnInit() {
	  
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_room = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_room.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }
	this.room.ID = +this.route.snapshot.paramMap.get('id');
	if (this.room.ID == 0){
		this.room_flag = 0;
	} else {
		this.getRoom();
	}
    
	
  }

  getRoom(): void {
	const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/room', JSON.stringify(this.room), {
        headers: headers
    }).subscribe((data : any) => {
        if (data.length != 0 ){
			this.room = data;
			this.room_flag = 1;
		} else {
			this.room_flag = 0;
		}
    },error => {
		this.error_flag = 1
        this.errors = error;
    }) 
  }
  
  onUpdate(data){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
	if (data.ID) {
      if (data.room_name != "" && data.room_name != null) {
		  this.http.post(environment.serverUrl+'/api/v1/room_update', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			//console.log(data)
			if (data.affectedRows == 1 || data.insertId == 1){        
			  //this.room = data;
			  this.room_flag = 1;
			  this.is_confirm_alert = 1;
			  this.is_show_alert = 0;
			} else {
			  this.is_db_alert = 1;
			  this.is_show_alert = 0;
			}
		  },error => {
			this.error_flag = 1
			this.errors = error;
		  }) 
	  } else {
		this.is_show_alert = 1;  
	  }
	} else {
	  if (data.room_name != "" && data.room_name != null) {
		this.http.post(environment.serverUrl+'/api/v1/room_create', JSON.stringify(data), {
			headers: headers
		  }).subscribe((data : any) => {
			//console.log(data)
			if (data.insertId != undefined){        
			  //this.room = data;
			  this.is_confirm_alert = 1;
			  this.is_show_alert = 0;
			} else {
			  this.is_db_alert = 1;
			  this.is_show_alert = 0;
			}
		  },error => {
			this.error_flag = 1
			this.errors = error;
		  })
	  } else {
		this.is_show_alert = 1;
		this.is_db_alert = 0;
		this.is_db_alert = 0;
	  }
	}
  }

}
