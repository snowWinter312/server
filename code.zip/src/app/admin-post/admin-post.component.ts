import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-admin-post',
  templateUrl: './admin-post.component.html',
  styleUrls: ['./admin-post.component.css']
})
export class AdminPostComponent implements OnInit {

  rememberMe : any
  current_post : any
  group_level=0;
  errors : any
  error_flag = 0;  
  post ={'ID':0, 'room_id':'', 'sub_room_id':'', 'tab_id':'','post_author':'', 'post_content':'', 'post_date':'', 'post_status':'', 'comment_status':'' }
  post_flag=0;
  is_show_alert = 0;
  is_confirm_alert = 0;
  is_db_alert = 0;
  post_content = "";
  post_status = 1;
  
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute) { }

  ngOnInit() {
	  
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
    if (!sessionStorage.getItem('group_level')){
	  this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
	} else if (this.rememberMe == true) {
      this.current_post = JSON.parse(localStorage.getItem('currentUser'))
	  if (!this.current_post.group_level){
		this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})  
	  }
    }
	this.post.ID = +this.route.snapshot.paramMap.get('id');
    this.getPost();
	
  }

  getPost(): void {
	const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.http.post(environment.serverUrl+'/api/v1/post', JSON.stringify(this.post), {
        headers: headers
    }).subscribe((data : any) => {
        if (data.length != 0 ){
			this.post = data;
			this.post_flag = 1;
		} else {
			this.post_flag = 0;
		}
    },error => {
		this.error_flag = 1
        this.errors = error;
    }) 
  }
  
  onUpdate(data){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    if (data.post_content != "" && data.post_content != null) {
      this.http.post(environment.serverUrl+'/api/v1/post_update', JSON.stringify(data), {
        headers: headers
      }).subscribe((data : any) => {
        //console.log(data)
        if (data.affectedRows == 1 || data.insertId == 1){        
          //this.post = data;
		  this.post_flag = 1;
		  this.is_confirm_alert = 1;
		  this.is_show_alert = 0;
        } else {
		  this.is_db_alert = 1;
		  this.is_show_alert = 0;
		}
      },error => {
		this.error_flag = 1
		this.errors = error;
	  }) 
	} else {
		this.is_show_alert = 1;
		this.is_db_alert = 0;
		this.is_db_alert = 0;
	}
  }

}
