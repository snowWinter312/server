import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {EncrDecrService} from '../encr-decr.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.css']
})
export class ConfirmComponent implements OnInit {
  user_activation_key = "";
  data = {"user_activation_key":"", }
  is_confirm_alert = false;
  is_error_alert = false;

  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute ,private EncrDecr: EncrDecrService) { }

  ngOnInit(): void {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
		this.data.user_activation_key=this.route.snapshot.paramMap.get('id');	
		
    this.http.post(environment.serverUrl+'/api/v1/confirm', JSON.stringify(this.data), {
      headers: headers
      }).subscribe((data : any) => {
            
      if (data.affectedRows == 1){
        this.is_confirm_alert = true
      } else {
        this.is_error_alert = true
      }
    })  
  }

}
