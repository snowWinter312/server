import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({
  name: 'sateHtml'
})
export class SateHtmlPipe implements PipeTransform {
/*
  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }
*/
  constructor(private sanitizer: DomSanitizer) {}

  transform(value) {
    return this.sanitizer.bypassSecurityTrustHtml(value);
  }
}
