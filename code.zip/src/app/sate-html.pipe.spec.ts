import { SateHtmlPipe } from './sate-html.pipe';

describe('SateHtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new SateHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
