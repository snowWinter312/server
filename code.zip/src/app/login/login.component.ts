import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {EncrDecrService} from '../encr-decr.service';
import {Location} from '@angular/common';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  location : Location;
	
  is_show_alert = false
  is_confirm_alert = false;
  rememberMe : any
  data : any
  constructor(private _router: Router, private http: HttpClient, private EncrDecr: EncrDecrService) { }

  ngOnInit() {
    
    console.log("--------------------------");
    this.is_show_alert = false
	this.rememberMe = localStorage.getItem('rememberCurrentUser') == 'true' ? true : false;
	if (sessionStorage.getItem('ID')){
	  this._router.navigateByUrl("/dashboard/0/0")	
	  this._router.onSameUrlNavigation = 'reload'    
	} else if(this.rememberMe == true) {
      this.data = JSON.parse(localStorage.getItem('currentUser'))
	  sessionStorage.setItem('ID', this.data.ID)
	  sessionStorage.setItem('username', this.data.username)
	  sessionStorage.setItem('email', this.data.email)
	  sessionStorage.setItem('role', this.data.role)
	  sessionStorage.setItem('group_level', this.data.group_level)
	  this._router.navigateByUrl("/dashboard/0/0")
	  this._router.onSameUrlNavigation = 'reload'    
    }
  }
	
  onClickSubmit(data){
    var username = data.username
    var pass = data.password
	  var remember = data.remember

    if ( username!= null && pass != null){
      this.is_show_alert = false
	    data.password = this.EncrDecr.set(pass);
      const headers = new HttpHeaders().set('Content-Type', 'application/json');
/*      
      this.http.post(environment.serverUrl+'/api/v1/register_email', JSON.stringify(data), {
				headers: headers
			}).subscribe((data : any) => {
				  if (data){
            this.is_confirm_alert = true
            console.log(data);
          }	
			  
			});
*/
      this.http.post(environment.serverUrl+'/api/v1/auth', JSON.stringify(data), {
        headers: headers
      }).subscribe((data : any) => {
        //console.log(data)
        
        if (data.length == 0 ){
          this.is_show_alert = true
        }else{
          if (remember){
          localStorage.setItem('currentUser', JSON.stringify(data[0]));
                localStorage.setItem('rememberCurrentUser', 'true');
          } else {
          localStorage.setItem('currentUser', '');
                localStorage.setItem('rememberCurrentUser', 'false');  
          }
          
              sessionStorage.setItem('ID', data[0].ID)
              sessionStorage.setItem('username', data[0].username)
              sessionStorage.setItem('email', data[0].email)
              sessionStorage.setItem('role', data[0].role)
              sessionStorage.setItem('group_level', data[0].group_level)
          sessionStorage.setItem('user', JSON.stringify(data[0]))
          //this._router.navigateByUrl('/', {skipLocationChange: true}).then(()=>this._router.navigate(["/dashboard/0/0"]));
              //this._router.navigateByUrl("/dashboard/0/0")
          //this._router.onSameUrlNavigation = 'reload'    
          this._router.navigate(["/dashboard/0/0"]).then(() => { window.location.reload();})
        }
      })

    }else{
      this.is_show_alert = true
    }

  }

}
