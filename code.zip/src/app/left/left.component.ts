import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-left',
  templateUrl: './left.component.html',
  styleUrls: ['./left.component.css']
})
export class LeftComponent implements OnInit {
  
  rooms = []
  roomFlag=0;
  room_number = +this.route.snapshot.paramMap.get('id1');
  tab_number = +this.route.snapshot.paramMap.get('id2');
  user_level = 0
  user : any

  constructor(private http: HttpClient,private route: ActivatedRoute) { }

  ngOnInit() {
    this.getRooms();	
  }

  getRooms(): void {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.user_level = +sessionStorage.getItem('role');
	  this.user = sessionStorage.getItem('user');
	  this.http.post(environment.serverUrl+'/api/v1/rooms', this.user, {
	  headers: headers
	}).subscribe((data : any) => {    
	  
	  if (data.length != 0  && data.length != undefined){
		this.rooms = data;
		this.roomFlag = 1;
	  }
	})	
  }
}
