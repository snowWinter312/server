export const environment = {
  production: true,
  //serverUrl: 'https://herosnowserver.herokuapp.com'
  serverUrl:'http://localhost:3000'
};
