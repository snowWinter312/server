function changeColor(id) {	
  if (id.style.backgroundColor == "#0590fa") {
	  id.style.backgroundColor = "#e9e9e9"
  } else {
	  id.style.backgroundColor = "#0590fa"
  }
}



function comment_add(){
	alert();	
}